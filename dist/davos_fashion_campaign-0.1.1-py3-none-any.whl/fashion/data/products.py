from fashion.schema import Product
import json
from typing import List

# Raw product data loaded from JSON
product_data = """[
  {
    "core_identifiers": {
      "sku": "185932",
      "upc": "850058932101",
      "brand": "Aurum",
      "product_name": "Black Satin Draped Midi Skirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Satin",
      "fit_type": "A-Line",
      "care_instructions": "Dry clean recommended. Can be hand washed cold. Lay flat to dry. Cool iron on reverse."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Evening Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 110.0,
      "current_price": 89.99,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 315,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/185932.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/185932_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a women's black satin midi skirt with an asymmetrical draped front and a flowing A-line silhouette."
    },
    "description": {
      "short": "An elegant black satin midi skirt featuring a sophisticated draped design and a flowing, asymmetrical hem.",
      "long": "Crafted from lustrous black satin, this midi skirt offers a touch of timeless elegance. The design features a flattering high-waist and an artfully gathered drape at the side, which flows into an asymmetrical wrap-style front. The A-line silhouette provides graceful movement, making it a perfect choice for special occasions, dinners, or creating a polished, chic look. Its versatile design pairs beautifully with both casual and formal tops."
    }
  },
  {
    "core_identifiers": {
      "sku": "192833",
      "upc": "840364192833",
      "brand": "Volt",
      "product_name": "Relaxed Fit Cargo Pants"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Olive Green",
      "color_hex": "#7A755A",
      "material": "Cotton Twill",
      "fit_type": "Relaxed Fit",
      "care_instructions": "Machine wash cold with like colors. Tumble dry low. Do not bleach. Warm iron if needed."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Core Essentials 2024"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 65.0,
      "cost_price": 29.5,
      "in_stock": true,
      "stock_quantity": 352,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/192833.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/192833_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of olive green relaxed fit cargo pants with multiple pockets, on a white background."
    },
    "description": {
      "short": "Durable and functional cargo pants crafted from sturdy cotton twill, featuring a relaxed fit and ample pocket space for everyday utility.",
      "long": "Meet your new go-to pants for any occasion. The Urban Expedition Relaxed Fit Cargo Pants are designed for durability, comfort, and timeless style. Made from a high-quality cotton twill fabric, these pants can withstand daily wear while maintaining a comfortable feel. The relaxed fit provides ease of movement, and the multiple large cargo pockets on the legs offer practical storage for all your essentials. The classic olive green color makes them incredibly versatile, easy to pair with anything from a simple t-shirt to a button-down shirt. Finished with a zip fly and button closure, these pants blend utilitarian design with modern aesthetics."
    }
  },
  {
    "core_identifiers": {
      "sku": "194821",
      "upc": "840344194821",
      "brand": "Maison Onyx",
      "product_name": "Quilted Faux Leather Chain Belt Shorts"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Faux Leather",
      "fit_type": "High-Waist",
      "care_instructions": "Wipe clean with a damp cloth. Do not machine wash. Do not bleach. Lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Midnight Glam"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 125.0,
      "current_price": 99.99,
      "cost_price": 45.75,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "low",
      "sales_reasoning": null,
      "q4_2025": "150 (-9%)",
      "q1_2026": "60 (-5%)"
    }, 
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/194821.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/194821_min.png",
      "gallery_urls": [],
      "alt_text": "Women's black high-waisted quilted faux leather shorts with an integrated belt featuring a gold chain detail."
    },
    "description": {
      "short": "Elevate your style with these chic black shorts, featuring a sophisticated quilted design and a striking gold-tone chain belt.",
      "long": "Crafted from supple faux leather, these high-waisted shorts showcase a classic diamond quilt pattern for a luxurious texture. The design is cinched at the waist with an integrated belt, highlighted by a bold, gold-tone curb chain at the front. These shorts offer a flattering fit and are perfect for creating an edgy, fashion-forward look for a night out or special event. Pair them with a sleek bodysuit and heels to complete the ensemble."
    }
  },
  {
    "core_identifiers": {
      "sku": "234444",
      "upc": "840348123456",
      "brand": "Maison Onyx",
      "product_name": "Faux Leather Straight-Leg Pants"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#0C0C0C",
      "material": "Faux Leather",
      "fit_type": "Straight-Leg",
      "care_instructions": "Wipe clean with a damp cloth. Do not machine wash. Do not bleach. Lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Downtown Edit"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 98.0,
      "current_price": 79.99,
      "cost_price": 38.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/234444.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/234444_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Front view of black faux leather straight-leg pants with five-pocket styling, isolated on a white background."
    },
    "description": {
      "short": "Sleek and modern faux leather pants with a classic straight-leg cut and five-pocket styling.",
      "long": "Introducing our Faux Leather Straight-Leg Pants, the perfect piece to add a touch of edge to any outfit. Crafted from a supple, high-quality faux leather, these pants feature a classic five-pocket design, a zip fly with a button closure, and seam detailing across the knees for added style. The flattering high-rise waist and straight-leg silhouette create a long, lean look. Pair them with a casual knit for daytime or a silk camisole for a night out."
    }
  },
  {
    "core_identifiers": {
      "sku": "238444",
      "upc": "197865432109",
      "brand": "Aurum",
      "product_name": "Ditsy Floral A-Line Maxi Skirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cream Multi Floral",
      "color_hex": "#FDFBF2",
      "material": "Viscose",
      "fit_type": "A-line",
      "care_instructions": "Machine wash cold on gentle cycle. Hang to dry. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Spring Bloom 2024"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 64.5,
      "cost_price": 29.75,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/238444.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/238444_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a women's A-line maxi skirt in a cream color with a ditsy floral pattern of small blue and yellow flowers."
    },
    "description": {
      "short": "A breezy and elegant A-line maxi skirt adorned with a delicate ditsy floral print.",
      "long": "Float through your day in our Ditsy Floral A-Line Maxi Skirt. Made from a lightweight and soft viscose fabric, this skirt offers beautiful movement and all-day comfort. The timeless A-line cut flatters your silhouette, while the charming all-over print of tiny blue and yellow blossoms on a cream background adds a touch of romantic, vintage-inspired style. Perfect for pairing with a simple tank top and sandals for an effortless warm-weather outfit."
    }
  },
  {
    "core_identifiers": {
      "sku": "294832",
      "upc": "840351829457",
      "brand": "Modern Muse",
      "product_name": "High-Waisted Pleated Culottes"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Oatmeal",
      "color_hex": "#EAE3D5",
      "material": "Wool Blend",
      "fit_type": "Wide-Leg",
      "care_instructions": "Dry clean only. Do not bleach. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Modern Essentials"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 225.0,
      "current_price": 198.0,
      "cost_price": 95.5,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/294832.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/294832_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of women's oatmeal colored high-waisted pleated wide-leg culottes with a single button closure."
    },
    "description": {
      "short": "Sophisticated and modern, these high-waisted culottes feature sharp pleats and a flattering wide-leg silhouette.",
      "long": "Elevate your wardrobe with our High-Waisted Pleated Culottes. Expertly tailored from a structured wool-blend fabric, they sit comfortably at the natural waist and flow into a graceful, wide-leg shape that ends at a cropped length. The crisp front pleats add volume and movement, creating a polished and contemporary look. These versatile trousers are perfect for transitioning from the office to an evening out, offering both comfort and impeccable style."
    }
  },
  {
    "core_identifiers": {
      "sku": "295883",
      "upc": "840361129588",
      "brand": "Neon & Co.",
      "product_name": "The Rigid Slouch Jean"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Vintage Indigo",
      "color_hex": "#3A506B",
      "material": "Denim",
      "fit_type": "Straight",
      "care_instructions": "Machine wash cold, inside out. Tumble dry low. Do not bleach."
    },
    "categorization": {
      "department": "Men",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Core Denim 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 118.0,
      "current_price": 98.0,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/295883.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/295883_min.png",
      "gallery_urls": [],
      "alt_text": "A pair of men's straight-leg jeans in a vintage indigo wash, shown flat on a white background."
    },
    "description": {
      "short": "A classic pair of straight-leg jeans crafted from durable, rigid denim with a vintage-inspired medium blue wash.",
      "long": "Meet your new favorite everyday jean. The Rigid Slouch Jean is designed with a classic straight fit that offers a comfortable, relaxed silhouette without being baggy. Made from 100% cotton rigid denim, these jeans will break in beautifully over time, molding to your shape for a personalized fit. The vintage indigo wash features authentic-looking fading and whiskering for a lived-in feel from the very first wear. Featuring a classic five-pocket design, zip fly, and button closure, these jeans are a versatile staple for any wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "394055",
      "upc": "840361123456",
      "brand": "Neon & Co.",
      "product_name": "High-Waisted Distressed Straight-Leg Jeans"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Light Wash Blue",
      "color_hex": "#7DA3C4",
      "material": "Denim",
      "fit_type": "Straight Leg",
      "care_instructions": "Machine wash cold with like colors, tumble dry low. Do not bleach."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Summer Street Style"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 88.0,
      "current_price": 74.99,
      "cost_price": 35.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/394055.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/394055_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Women's light wash blue straight-leg jeans with significant distressing and large rips at both knees, featuring a high-rise waist and a raw hem."
    },
    "description": {
      "short": "A pair of light wash blue straight-leg jeans with a high-waisted fit. Features heavy distressing and large, open rips at the knees for an edgy, modern look.",
      "long": "Make a statement with our High-Waisted Distressed Straight-Leg Jeans. Crafted from 100% cotton denim for an authentic vintage feel, these jeans come in a classic light wash blue. The design features a flattering high-rise waist, a standard five-pocket layout, and a straight-leg cut that offers a relaxed yet stylish silhouette. The defining characteristic is the bold, heavy distressing throughout, with prominent rips at the knees that add a touch of rebellious charm. Finished with a frayed, raw hem, these jeans are perfect for pairing with sneakers and a simple tee for an effortlessly cool weekend outfit."
    }
  },
  {
    "core_identifiers": {
      "sku": "394855",
      "upc": "196428394855",
      "brand": "Neon & Co.",
      "product_name": "Pleated Plaid Mini Skirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Red Tartan",
      "color_hex": "#D22B2B",
      "material": "Polyester Blend",
      "fit_type": "A-Line",
      "care_instructions": "Machine wash cold on gentle cycle. Hang to dry. Do not bleach."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Campus Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 48.0,
      "current_price": 39.99,
      "cost_price": 18.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/394855.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/394855_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A women's pleated mini skirt with a red, black, and white plaid pattern on a white background."
    },
    "description": {
      "short": "A classic and preppy pleated mini skirt featuring a vibrant red, black, and white tartan plaid pattern.",
      "long": "Channel a timeless academic look with our Pleated Plaid Mini Skirt. This skirt features a classic A-line silhouette with crisp pleats that offer a flattering shape and movement. The striking red tartan pattern, interwoven with black and white lines, makes a bold statement. Made from a comfortable and durable fabric, it's perfect for all-day wear. It includes a concealed side zipper for a seamless look. Pair it with a chunky sweater and boots for a cozy autumn outfit or a simple blouse for a polished, preppy style."
    }
  },
  {
    "core_identifiers": {
      "sku": "554345",
      "upc": "198765432109",
      "brand": "Modern Muse",
      "product_name": "Tweed Pencil Skirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cream Multi",
      "color_hex": "#F5F5DC",
      "material": "Tweed",
      "fit_type": "Pencil",
      "care_instructions": "Dry Clean Only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Autumn Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 110.0,
      "current_price": 89.99,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 158,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/554345.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/554345_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a high-waisted tweed pencil skirt in a cream and beige pattern."
    },
    "description": {
      "short": "A classic high-waisted pencil skirt crafted from textured tweed, perfect for sophisticated office or evening wear.",
      "long": "Elevate your wardrobe with our timeless Tweed Pencil Skirt. This piece is beautifully constructed from a high-quality, textured tweed fabric in a versatile cream multi-color weave. The flattering high-waist and pencil silhouette create a polished and professional look that transitions effortlessly from day to night. Featuring a concealed back zipper for a smooth fit, this skirt is a must-have for any modern classic collection. Pair it with a crisp blouse or a fine-knit sweater for an elegant ensemble."
    }
  },
  {
    "core_identifiers": {
      "sku": "583944",
      "upc": "840350112345",
      "brand": "Volt",
      "product_name": "Unisex Fleece Jogger Sweatpants"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Charcoal Gray",
      "color_hex": "#5A5A5A",
      "material": "Fleece",
      "fit_type": "Regular",
      "care_instructions": "Machine wash cold with like colors. Tumble dry low. Do not bleach. Do not iron."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Core Activewear"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 55.0,
      "current_price": 45.99,
      "cost_price": 21.5,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/583944.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/583944_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of charcoal gray fleece jogger sweatpants with a drawstring waist and elastic cuffs."
    },
    "description": {
      "short": "Classic fleece jogger sweatpants in a versatile charcoal gray, featuring a comfortable drawstring waist and cuffed ankles.",
      "long": "Stay comfortable and stylish with our Unisex Fleece Jogger Sweatpants. Made from a soft and warm fleece material, these pants are perfect for lounging, working out, or running errands. They feature an adjustable drawstring for a custom fit, convenient side pockets, and elastic-cuffed ankles for a modern jogger silhouette. The classic charcoal gray color makes them a versatile addition to any casual wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "598345",
      "upc": "840345123456",
      "brand": "Aurum",
      "product_name": "Ditsy Floral Maxi Skirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cream Multi Floral",
      "color_hex": "#F5F5DC",
      "material": "Viscose",
      "fit_type": "A-Line",
      "care_instructions": "Machine wash cold on gentle cycle. Hang to dry. Iron on low heat."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Spring Bloom Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 64.99,
      "cost_price": 32.5,
      "in_stock": true,
      "stock_quantity": 245,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/598345.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/598345_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a cream-colored A-line maxi skirt with a ditsy pastel floral print."
    },
    "description": {
      "short": "A flowy A-line maxi skirt featuring a delicate ditsy floral print on a soft cream background, perfect for warm weather.",
      "long": "Embrace effortless elegance with our Ditsy Floral Maxi Skirt. Crafted from lightweight, breathable viscose, this skirt drapes beautifully in a flattering A-line silhouette. The delicate pastel floral pattern adds a touch of romantic charm, making it perfect for sunny days, garden parties, or a casual brunch. It features a comfortable waistband and a full-length cut for a graceful, flowing movement with every step. Pair it with a simple camisole or a fitted tee for a timeless look."
    }
  },
  {
    "core_identifiers": {
      "sku": "839185",
      "upc": "198765432109",
      "brand": "Modern Muse",
      "product_name": "High-Waisted Houndstooth Trousers"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black/White Houndstooth",
      "color_hex": "#000000",
      "material": "Wool Blend",
      "fit_type": "Wide-Leg",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Autumn Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 128.0,
      "current_price": 99.99,
      "cost_price": 45.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/839185.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/839185_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of women's high-waisted wide-leg trousers in a black and white houndstooth pattern."
    },
    "description": {
      "short": "Classic high-waisted trousers featuring a timeless black and white houndstooth pattern and a modern wide-leg silhouette.",
      "long": "Elevate your wardrobe with these sophisticated High-Waisted Houndstooth Trousers. Expertly tailored from a quality wool-blend fabric, they offer both structure and comfort. The classic black and white houndstooth print provides a timeless appeal, while the high-waisted design and front pleats create a flattering shape. A relaxed, wide-leg cut ensures ease of movement and a chic, flowing silhouette. These trousers are a versatile addition, perfect for transitioning from a professional office setting to an elegant evening out."
    }
  },
  {
    "core_identifiers": {
      "sku": "90802",
      "upc": "840350112345",
      "brand": "Neon & Co.",
      "product_name": "Classic Straight Fit Jeans"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Medium Wash Blue",
      "color_hex": "#3A5A8A",
      "material": "Denim",
      "fit_type": "Straight",
      "care_instructions": "Machine wash cold with like colors, tumble dry low. Do not bleach. Iron on medium heat if needed."
    },
    "categorization": {
      "department": "Men",
      "category": "Apparel",
      "sub_category": "Bottom",
      "collection": "Core Essentials"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 88.0,
      "current_price": 75.5,
      "cost_price": 35.25,
      "in_stock": true,
      "stock_quantity": 341,
      "sales_velocity": "high",
      "sales_reasoning": "Consistent top-seller in the denim category.",
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/90802.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/bottom/90802_min.png",
      "gallery_urls": [],
      "alt_text": "A pair of men's straight fit jeans in a medium blue wash, shown flat on a white background."
    },
    "description": {
      "short": "A timeless pair of straight-fit jeans crafted from comfortable denim, featuring a classic medium wash and five-pocket styling.",
      "long": "Meet your new favorite jeans. Our Classic Straight Fit Jeans are designed for both style and comfort, making them a versatile staple for any wardrobe. Made from high-quality, durable denim with a hint of stretch, they offer a perfect fit that moves with you. The medium blue wash is enhanced with subtle whiskering and fading for an authentic, lived-in look right from the start. Featuring a traditional five-pocket design, zip fly, and button closure, these jeans are the ideal foundation for any casual outfit."
    }
  },
  {
    "core_identifiers": {
      "sku": "119283",
      "upc": "850051234567",
      "brand": "Maison Onyx",
      "product_name": "Pearl-Collar Sleeveless Sheath Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Crepe",
      "fit_type": "Sheath Fit",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Cocktail & Evening Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 198.0,
      "current_price": 179.99,
      "cost_price": 85.5,
      "in_stock": true,
      "stock_quantity": 125,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/119283.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/119283_min.png",
      "gallery_urls": [],
      "alt_text": "Sleeveless black sheath dress with a pearl-embellished jewel neckline, front view."
    },
    "description": {
      "short": "An elegant sleeveless black sheath dress featuring a sophisticated pearl-embellished jewel neckline. Perfect for formal events and cocktail parties.",
      "long": "Exude timeless sophistication in our Pearl-Collar Sleeveless Sheath Dress. Tailored to perfection, this classic black dress features a flattering sheath silhouette that skims the body beautifully. The standout detail is the exquisite pearl-embellished jewel neckline, adding a touch of luxury and eliminating the need for a necklace. Crafted from a high-quality crepe fabric with a hint of stretch for comfort, it's fully lined and fastens with a concealed back zipper. A versatile and chic addition to any wardrobe, this dress is ideal for cocktail hours, weddings, or any formal occasion where you want to make a lasting impression."
    }
  },
  {
    "core_identifiers": {
      "sku": "119928",
      "upc": "840351899234",
      "brand": "Maison Onyx",
      "product_name": "Floral V-Neck Button-Front Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black Floral",
      "color_hex": "#000000",
      "material": "Viscose",
      "fit_type": "Fit and Flare",
      "care_instructions": "Machine wash cold on gentle cycle. Hang to dry. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Spring Garden Party"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 62.5,
      "cost_price": 29.75,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/119928.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/119928_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A woman's black V-neck, cap sleeve, button-front midi dress with a pink and white rose floral print."
    },
    "description": {
      "short": "A charming black midi dress featuring a romantic rose floral print, a V-neckline, and a classic button-front design.",
      "long": "Step into effortless style with our Floral V-Neck Button-Front Dress. This piece features a timeless black background adorned with a lovely print of pink and white roses. Designed with a flattering V-neck, delicate cap sleeves, and a full button-front placket, this midi-length dress offers a perfect blend of comfort and chic sophistication. The lightweight viscose fabric ensures a beautiful drape, making it an ideal choice for brunches, day events, or warm-weather evenings."
    }
  },
  {
    "core_identifiers": {
      "sku": "192838",
      "upc": "194567890123",
      "brand": "Modern Muse",
      "product_name": "Sleeveless Tweed Mini Dress with Contrast Trim"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cream/Black",
      "color_hex": "#F5F5DC",
      "material": "Tweed",
      "fit_type": "Shift",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Pre-Fall 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 445.0,
      "current_price": 445.0,
      "cost_price": 198.75,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192838.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192838_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A sleeveless cream tweed mini dress with black contrast trim on the neckline, armholes, and four front patch pockets with silver buttons."
    },
    "description": {
      "short": "A timelessly chic sleeveless mini dress crafted from textured tweed, featuring elegant black contrast trim and four patch pockets for a touch of classic sophistication.",
      "long": "This beautifully constructed shift dress channels classic Parisian elegance. Made from a high-quality cream-colored tweed, it offers both texture and structure. The sleeveless design is complemented by bold black trim along the round neck and armholes. Four patch pockets, two at the chest and two at the hips, are also accented with black trim and finished with ornate silver-tone buttons. A concealed back zipper provides a clean, tailored fit. This versatile piece is perfect for transitioning from a daytime meeting to an evening event with effortless style."
    }
  },
  {
    "core_identifiers": {
      "sku": "192841",
      "upc": "840344519286",
      "brand": "Maison Onyx",
      "product_name": "Symmetrical Kaleidoscope Print Maxi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Multi-Color",
      "color_hex": "#0A2F4B",
      "material": "Polyester Spandex Blend",
      "fit_type": "A-Line",
      "care_instructions": "Machine wash cold on gentle cycle. Tumble dry low. Do not bleach. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Artisan Prints"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 135.0,
      "current_price": 110.0,
      "cost_price": 52.5,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192841.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192841_min.png",
      "gallery_urls": [],
      "alt_text": "Women's long sleeve high-neck maxi dress with a vibrant symmetrical geometric and paisley print in green, yellow, and blue."
    },
    "description": {
      "short": "A stunning high-neck, long-sleeve maxi dress featuring a vibrant and intricate symmetrical kaleidoscope print. The A-line silhouette offers a flattering and comfortable fit for any occasion.",
      "long": "Make a bold and artistic statement with our Symmetrical Kaleidoscope Print Maxi Dress. This beautifully designed piece features a sophisticated high neckline and elegant long sleeves. The dress showcases a mesmerizing, symmetrical pattern rich in deep blues, vibrant greens, and golden yellows, reminiscent of intricate tile work. Crafted from a soft and stretchy polyester-spandex blend, it drapes beautifully in a flattering A-line cut that flows to the ankle. Perfect for gallery openings, special dinners, or any event where you want to stand out, this dress combines comfort with high-fashion artistry."
    }
  },
  {
    "core_identifiers": {
      "sku": "192844",
      "upc": "840348192844",
      "brand": "Modern Muse",
      "product_name": "Geometric Print Satin Shirtdress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cream/Grey",
      "color_hex": "#F3EFE9",
      "material": "Satin",
      "fit_type": "Regular Fit",
      "care_instructions": "Dry clean recommended. Cool iron on reverse."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Modern Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 325.0,
      "current_price": 275.0,
      "cost_price": 135.0,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192844.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/192844_min.png",
      "gallery_urls": [],
      "alt_text": "Women's long-sleeve collared shirtdress in a cream and grey geometric pattern with a matching belt."
    },
    "description": {
      "short": "A sophisticated long-sleeve shirtdress crafted from smooth satin, featuring a striking geometric print and a self-tie belt to cinch the waist.",
      "long": "This elegant shirtdress is designed for a timeless appeal. It's crafted from a fluid satin fabric that drapes beautifully. The dress features a classic point collar, a full button-down front, and long sleeves with cuffed ends. A bold geometric print covers the entirety of the dress, offering a modern, graphic look. A matching fabric belt allows you to define your silhouette. The knee-length cut and curved hem make it a versatile piece for both professional settings and special occasions."
    }
  },
  {
    "core_identifiers": {
      "sku": "229384",
      "upc": "840348129384",
      "brand": "Maison Onyx",
      "product_name": "Asymmetrical Rib-Knit Midi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Ribbed Knit",
      "fit_type": "Bodycon",
      "care_instructions": "Hand wash cold. Do not bleach. Lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Evening Edit"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 59.99,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/229384.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/229384_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A black long-sleeve rib-knit midi dress with an asymmetrical one-shoulder neckline and a thigh-high slit."
    },
    "description": {
      "short": "Make a statement in this elegant black rib-knit midi dress. Featuring a modern asymmetrical neckline and a daring side slit, this dress offers a sophisticated and form-fitting silhouette.",
      "long": "Crafted from a comfortable stretch rib-knit fabric, this stunning black midi dress is designed to hug your curves. The unique asymmetrical neckline combines a single strap with an off-the-shoulder detail for a contemporary look. Long sleeves provide coverage, while the thigh-high side slit adds a touch of allure. Perfect for date nights, cocktail parties, or any special occasion, this bodycon dress is a versatile and timeless addition to your wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "293852",
      "upc": "850024987123",
      "brand": "Maison Onyx",
      "product_name": "Satin Jacquard Wrap Midi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Navy Blue",
      "color_hex": "#19213D",
      "material": "Satin Jacquard",
      "fit_type": "Wrap",
      "care_instructions": "Hand wash cold. Do not bleach. Line dry. Cool iron if necessary."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Evening Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 350.0,
      "current_price": 325.0,
      "cost_price": 150.0,
      "in_stock": true,
      "stock_quantity": 185,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/293852.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/293852_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a women's navy blue satin jacquard long-sleeve wrap midi dress on a white background."
    },
    "description": {
      "short": "Elevate your evening look with this stunning navy blue satin jacquard wrap dress, featuring long bishop sleeves and a flattering midi length.",
      "long": "Crafted from a luxurious satin jacquard fabric with a subtle polka dot pattern, this wrap dress exudes timeless elegance. It's designed with a classic V-neckline, voluminous long bishop sleeves with cuffed wrists, and a self-tie belt to cinch the waist for a defined silhouette. The flowing midi-length skirt creates beautiful movement, making it perfect for special occasions, cocktail parties, or formal dinners. The wrap design ensures a comfortable and adjustable fit for effortless sophistication."
    }
  },
  {
    "core_identifiers": {
      "sku": "343485",
      "upc": "840345123456",
      "brand": "Maison Onyx",
      "product_name": "Embellished Tweed Sheath Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black/White Multi",
      "color_hex": "#FFFFFF",
      "material": "Tweed",
      "fit_type": "Sheath",
      "care_instructions": "Dry Clean Only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Fall/Winter 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 495.0,
      "current_price": 450.0,
      "cost_price": 312.75,
      "in_stock": true,
      "stock_quantity": 85,
      "sales_velocity": "low",
      "sales_reasoning": null,
      "q4_2025": "130 (-9%)",
      "q1_2026": "25 (-8%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/343485.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/343485_min.png",
      "gallery_urls": [],
      "alt_text": "A short-sleeved tweed mini dress in black and white with embellished trim along the crew neck, cuffs, waist, and faux pocket details."
    },
    "description": {
      "short": "A beautifully crafted tweed mini dress featuring a black and white pattern with sparkling embellishments. This sheath dress has a classic crew neck and short sleeves, perfect for a sophisticated and polished look.",
      "long": "Exude timeless elegance with this Embellished Tweed Sheath Dress. Expertly tailored from a rich, textured tweed fabric, this piece showcases a sophisticated black and white pattern interwoven with subtle metallic threads for a hint of shimmer. The dress is designed in a flattering sheath silhouette that hugs the body gracefully. It features a classic crew neckline, short sleeves, and is accented with intricate beaded and frayed trim along the collar, cuffs, defined waistline, and hem. This dress is a perfect choice for formal events, business meetings, or any occasion where you want to make a chic statement."
    }
  },
  {
    "core_identifiers": {
      "sku": "443323",
      "upc": "198765432109",
      "brand": "Maison Onyx",
      "product_name": "Ruby Red Silk Cowl Neck Slip Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Ruby Red",
      "color_hex": "#9B111E",
      "material": "Silk",
      "fit_type": "Slim Fit",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Evening Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 295.0,
      "current_price": 249.99,
      "cost_price": 120.5,
      "in_stock": true,
      "stock_quantity": 158,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/443323.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/443323_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a ruby red silk slip dress with a cowl neckline and spaghetti straps on a white background."
    },
    "description": {
      "short": "An elegant ruby red slip dress crafted from lustrous silk, featuring a graceful cowl neckline and delicate spaghetti straps.",
      "long": "Make a stunning entrance in our Ruby Red Silk Cowl Neck Slip Dress. Cut on the bias from pure, fluid silk, this dress skims your figure for a flattering, slim fit. The elegant cowl neckline adds a touch of classic glamour, while the delicate spaghetti straps provide a minimalist finish. Falling to a sophisticated midi length, this piece is perfect for cocktail parties, weddings, or any special occasion where you want to feel effortlessly chic. Its rich ruby hue is both timeless and captivating."
    }
  },
  {
    "core_identifiers": {
      "sku": "492834",
      "upc": "850043219876",
      "brand": "Maison Onyx",
      "product_name": "Pink Geometric Print Mock Neck Midi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Fuchsia Kaleidoscope",
      "color_hex": "#D94A8C",
      "material": "Satin",
      "fit_type": "Fit and Flare",
      "care_instructions": "Dry clean recommended"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Autumn Bloom 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 245.0,
      "current_price": 210.0,
      "cost_price": 98.5,
      "in_stock": true,
      "stock_quantity": 178,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/492834.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/492834_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a pink geometric print midi dress with a high mock neck, long bishop sleeves with buttoned cuffs, and an A-line silhouette."
    },
    "description": {
      "short": "A vibrant midi dress featuring a striking geometric print in shades of pink, a sophisticated mock neck, and elegant long bishop sleeves.",
      "long": "Turn heads in this beautifully designed midi dress. It is crafted from a smooth satin fabric that drapes elegantly over the body. The dress features a chic mock neck, a fitted waist that flows into an A-line skirt, and romantic long bishop sleeves with detailed buttoned cuffs. The bold, kaleidoscopic geometric print in fuchsia, pink, and deep magenta makes this a perfect statement piece for special occasions, brunches, or evening events."
    }
  },
  {
    "core_identifiers": {
      "sku": "524146",
      "upc": "840344152871",
      "brand": "Maison Onyx",
      "product_name": "Faux Leather Corset Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Chocolate Brown",
      "color_hex": "#4d2e2e",
      "material": "Faux Leather",
      "fit_type": "Slim Fit",
      "care_instructions": "Wipe clean with a damp cloth. Do not machine wash. Do not bleach. Lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "After Hours"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 98.0,
      "current_price": 79.99,
      "cost_price": 38.5,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/524146.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/524146_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A women's chocolate brown faux leather mini dress with a corset-style bodice and thick straps, shown on a white background."
    },
    "description": {
      "short": "A captivating faux leather mini dress designed with a structured corset bodice and a sleek, body-hugging silhouette.",
      "long": "Command attention in this stunning Faux Leather Corset Mini Dress. Crafted from a supple, high-quality faux leather in a rich chocolate brown hue, this piece is a modern essential for any bold wardrobe. The dress features a structured corset bodice with defined cups and boning details to create a flattering, sculpted shape. Wide shoulder straps and a square neckline add a contemporary touch, while the slim-fit mini skirt elongates the legs. Perfect for a night out on the town or a special event."
    }
  },
  {
    "core_identifiers": {
      "sku": "543444",
      "upc": "850058310921",
      "brand": "Maison Onyx",
      "product_name": "Floral Lace V-Neck Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black Multi Floral",
      "color_hex": "#000000",
      "material": "Rayon with Lace Trim",
      "fit_type": "Fit and Flare",
      "care_instructions": "Hand wash cold. Do not bleach. Hang to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Summer Garden Party"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 68.0,
      "current_price": 49.99,
      "cost_price": 22.5,
      "in_stock": true,
      "stock_quantity": 178,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/543444.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/543444_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Women's black floral print mini dress with a deep V-neckline and black lace trim on the neckline, sleeves, and waist."
    },
    "description": {
      "short": "A charming and romantic floral mini dress featuring a deep V-neck and elegant black lace detailing.",
      "long": "Fall in love with this beautifully designed floral mini dress. It features a vibrant, multi-colored floral pattern set against a classic black background. The flattering fit-and-flare silhouette is enhanced by delicate black lace trim along the plunging V-neckline, cap sleeves, and empire waist. Made from a lightweight and breathable fabric, this dress is perfect for warm weather occasions, from daytime outings to evening events."
    }
  },
  {
    "core_identifiers": {
      "sku": "555734",
      "upc": "198765432109",
      "brand": "Maison Onyx",
      "product_name": "Galaxy Glow Glitter Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Rainbow Glitter",
      "color_hex": "#8A2BE2",
      "material": "Glitter Mesh",
      "fit_type": "Bodycon",
      "care_instructions": "Hand wash cold, hang to dry"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Cosmic Nights Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 59.99,
      "current_price": 44.99,
      "cost_price": 22.5,
      "in_stock": true,
      "stock_quantity": 287,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/555734.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/555734_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Front view of a bodycon spaghetti strap mini dress in a shimmering rainbow glitter fabric."
    },
    "description": {
      "short": "Shine like a galaxy in this stunning rainbow glitter mini dress. Perfect for nights out and special occasions.",
      "long": "Steal the spotlight in our Galaxy Glow Glitter Mini Dress. This eye-catching bodycon dress features a vibrant, iridescent rainbow pattern on a shimmering mesh fabric. Designed with delicate spaghetti straps and a flattering slim fit, it hugs your curves in all the right places. The double-layered construction provides coverage while maintaining a lightweight feel. Ideal for parties, clubs, or any event where you want to make a dazzling impression. Pair it with your favorite heels for an unforgettable look."
    }
  },
  {
    "core_identifiers": {
      "sku": "593844",
      "upc": "840351892147",
      "brand": "Neon & Co.",
      "product_name": "Women's Sporty Zip-Up Bodycon Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Royal Blue",
      "color_hex": "#00539C",
      "material": "Polyester/Spandex Blend",
      "fit_type": "Bodycon",
      "care_instructions": "Machine wash cold with like colors. Tumble dry low. Do not bleach. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Athleisure"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 75.0,
      "current_price": 59.99,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/593844.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/593844_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A women's long-sleeve, royal blue bodycon dress with a high collar, full front zipper, and white piping detail along the shoulders and sleeves."
    },
    "description": {
      "short": "A sporty yet chic long-sleeve bodycon dress in a vibrant royal blue, featuring a full front zip and contrasting white piping for an athletic-inspired aesthetic.",
      "long": "Merge style and comfort with our Sporty Zip-Up Bodycon Dress. Designed for a modern, active lifestyle, this dress is crafted from a flexible polyester and spandex blend that contours to your body for a flattering, slim fit. It features a high mock neck, a full-length front zipper for versatile styling, and long sleeves. The design is elevated by crisp white piping along the raglan sleeves, adding a touch of athletic flair. Perfect for a casual day out or a stylish athleisure look, this dress is a versatile addition to any wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "634234",
      "upc": "198765432109",
      "brand": "Aurum",
      "product_name": "Floral Puff Sleeve Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Pink Multi Floral",
      "color_hex": "#E6C0C1",
      "material": "Jacquard",
      "fit_type": "Fitted",
      "care_instructions": "Dry Clean Only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Spring Blossom Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 225.0,
      "current_price": 180.0,
      "cost_price": 90.0,
      "in_stock": true,
      "stock_quantity": 158,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/634234.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/634234_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a women's pink floral mini dress with short puff sleeves."
    },
    "description": {
      "short": "A charming floral mini dress featuring elegant puff sleeves and a flattering fitted silhouette, perfect for spring occasions.",
      "long": "Embrace romantic style with our Floral Puff Sleeve Mini Dress. Crafted from a beautiful floral jacquard fabric, this dress boasts a delicate color palette of pink, yellow, and red. The statement puff sleeves add a touch of modern drama, while the fitted bodice and A-line skirt create a timelessly feminine silhouette. A concealed back zipper ensures a seamless fit. Ideal for garden parties, brunches, or any special event, this dress is a standout piece for your wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "634544",
      "upc": "850024681357",
      "brand": "Maison Onyx",
      "product_name": "Amalfi Long Sleeve Cut Out Mini Dress in White"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "White",
      "color_hex": "#FFFFFF",
      "material": "Ribbed Knit",
      "fit_type": "Bodycon",
      "care_instructions": "Machine wash cold, gentle cycle. Lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Evening Edit"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 75.0,
      "current_price": 59.99,
      "cost_price": 25.5,
      "in_stock": true,
      "stock_quantity": 234,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/634544.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/634544_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a white long-sleeve ribbed bodycon mini dress with a square neckline and chest cutout."
    },
    "description": {
      "short": "A stunning long-sleeve bodycon mini dress in a white ribbed knit, featuring a unique square neckline with a chic cut-out detail.",
      "long": "Turn heads in the Amalfi mini dress. Crafted from our premium ribbed knit fabric that hugs your curves, this dress features long sleeves, a bodycon fit, and a mini length. The standout detail is the modern square neckline, enhanced with a captivating cut-out at the chest. Perfect for date nights or evenings out with the girls, this dress combines sophistication with a touch of allure. The integrated waistband cinches your figure for the most flattering silhouette."
    }
  },
  {
    "core_identifiers": {
      "sku": "643575",
      "upc": "850024567890",
      "brand": "Maison Onyx",
      "product_name": "Psychedelic Swirl Cowl Neck Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Sunset Swirl",
      "color_hex": "#F9A825",
      "material": "Satin",
      "fit_type": "Slim Fit",
      "care_instructions": "Hand wash cold, do not bleach, line dry, iron low."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "70s Revival"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 65.0,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 288,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/643575.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/643575_min.png",
      "gallery_urls": [],
      "alt_text": "A women's mini slip dress with a colorful psychedelic swirl pattern, cowl neckline, and thin spaghetti straps."
    },
    "description": {
      "short": "A vibrant mini slip dress featuring a 70s-inspired psychedelic swirl print, a flattering cowl neckline, and a slim, body-skimming fit.",
      "long": "Step back in time with our Psychedelic Swirl Cowl Neck Mini Dress. Made from a silky satin material, this dress features a bold and colorful swirl pattern in hues of orange, purple, blue, and yellow. The design includes a chic cowl neck and delicate, adjustable spaghetti straps. Its slim-fit silhouette flatters your figure, making it the perfect statement piece for parties, festivals, or a night out on the town."
    }
  },
  {
    "core_identifiers": {
      "sku": "653444",
      "upc": "805673912345",
      "brand": "Neon & Co.",
      "product_name": "Graffiti Print T-Shirt Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "White",
      "color_hex": "#FFFFFF",
      "material": "Cotton",
      "fit_type": "Relaxed",
      "care_instructions": "Machine wash cold. Do not bleach. Tumble dry low. Cool iron if needed. Do not dry clean."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Summer Streetwear '23"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 195.0,
      "current_price": 149.99,
      "cost_price": 75.5,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "low",
      "sales_reasoning": null,
      "q4_2025": "96 (-6%)",
      "q1_2026": "30 (-4%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/653444.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/653444_min.png",
      "gallery_urls": [],
      "alt_text": "Women's white t-shirt dress with a colorful graffiti logo print on the chest and an asymmetric ruched hem."
    },
    "description": {
      "short": "A relaxed-fit t-shirt dress in white cotton, featuring a bold, colorful graffiti-style graphic on the chest and a stylish asymmetric ruched hem.",
      "long": "Embrace urban edge with this comfortable and stylish t-shirt dress. Made from 100% soft cotton, this dress features a classic crew neck and short sleeves for a casual feel. The front is adorned with a vibrant, multi-colored graffiti print, making a bold statement. The design is elevated with a modern, asymmetric ruched detail on the side, leading to a subtle side slit for added style and movement. This dress offers a relaxed fit, perfect for everyday wear or making an impression."
    }
  },
  {
    "core_identifiers": {
      "sku": "654567",
      "upc": "198765432109",
      "brand": "Maison Onyx",
      "product_name": "Lavender Ruched Strapless Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Lavender",
      "color_hex": "#C8A2C8",
      "material": "Polyester/Spandex Blend",
      "fit_type": "Bodycon",
      "care_instructions": "Machine wash cold on gentle cycle. Hang to dry. Do not bleach."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Summer Soiree"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 55.0,
      "current_price": 42.5,
      "cost_price": 19.99,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/654567.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/654567_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Front view of a lavender strapless bodycon mini dress with ruched sides and adjustable drawstrings."
    },
    "description": {
      "short": "A stunning strapless bodycon mini dress in a beautiful lavender hue. Features adjustable ruching with drawstrings on the sides for a customizable and flattering fit.",
      "long": "Step out in style with our Lavender Ruched Strapless Mini Dress. This eye-catching piece is designed to hug your curves in all the right places. Made from a soft and stretchy fabric, it ensures both comfort and a flawless silhouette. The dress features a classic strapless neckline and intricate ruching down the sides, which can be adjusted with drawstrings to create your desired look and length. Perfect for parties, date nights, or any event where you want to make a statement. Pair it with heels and delicate jewelry for an unforgettable ensemble."
    }
  },
  {
    "core_identifiers": {
      "sku": "735634",
      "upc": "840345123456",
      "brand": "Maison Onyx",
      "product_name": "Metallic Halter Cowl Neck Midi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Gunmetal",
      "color_hex": "#848482",
      "material": "Metallic Lurex Blend",
      "fit_type": "Slim Fit",
      "care_instructions": "Hand wash cold separately. Do not bleach. Lay flat to dry. Cool iron on reverse side if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Midnight Shimmer"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 148.0,
      "current_price": 119.99,
      "cost_price": 58.5,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/735634.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/735634_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A women's gunmetal metallic midi dress with a halter neckline and a draped cowl front, shown on a white background."
    },
    "description": {
      "short": "A stunning gunmetal metallic midi dress featuring an elegant halter neckline and a flattering cowl front. Perfect for evening events and special occasions.",
      "long": "Command attention in this exquisite Metallic Halter Cowl Neck Midi Dress. Expertly crafted from a shimmering lurex blend, this dress is designed to catch the light from every angle. It features a sophisticated halter neck that ties at the back and a gracefully draped cowl neckline that adds a touch of classic glamour. The slim-fit silhouette hugs your figure before falling to an elegant midi length, creating a sleek and modern look. Whether you're attending a cocktail party or a formal dinner, this dress is your go-to for making a memorable statement."
    }
  },
  {
    "core_identifiers": {
      "sku": "745624",
      "upc": "198765432109",
      "brand": "Aurum",
      "product_name": "Ribbed Knit Long Sleeve Maxi Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Heather Taupe",
      "color_hex": "#8A7F74",
      "material": "Wool Blend",
      "fit_type": "Slim Fit",
      "care_instructions": "Hand wash cold, lay flat to dry. Do not bleach. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Modern Essentials"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 158.0,
      "current_price": 129.0,
      "cost_price": 62.5,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/745624.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/745624_min.png",
      "gallery_urls": [],
      "alt_text": "A women's long-sleeve, crew neck, ribbed knit maxi dress in heather taupe with a high side slit on the left leg."
    },
    "description": {
      "short": "An elegant and modern long-sleeve maxi dress crafted from a comfortable ribbed knit fabric. Features a slim, body-contouring fit and a tasteful side slit for added movement and style.",
      "long": "Discover timeless elegance with our Ribbed Knit Long Sleeve Maxi Dress. Designed to flatter, this dress features a slim, figure-hugging silhouette crafted from a soft and stretchy wool-blend knit. The classic crew neckline and long sleeves provide sophisticated coverage, while a high side slit introduces a contemporary edge and ensures ease of movement. Rendered in a versatile heather taupe, this dress is a perfect foundation piece for any modern wardrobe, easily dressed up or down for any occasion."
    }
  },
  {
    "core_identifiers": {
      "sku": "982349",
      "upc": "196924009823",
      "brand": "Maison Onyx",
      "product_name": "Tweed Sleeveless Mini Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "White/Black",
      "color_hex": "#F5F5F5",
      "material": "Tweed",
      "fit_type": "Sheath",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Classic Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 495.0,
      "current_price": 450.0,
      "cost_price": 180.0,
      "in_stock": true,
      "stock_quantity": 85,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/982349.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/982349_min.png",
      "gallery_urls": [],
      "alt_text": "White and black tweed sleeveless mini dress with button details."
    },
    "description": {
      "short": "A timeless sleeveless mini dress crafted from classic tweed, featuring contrasting black trim and elegant button embellishments.",
      "long": "Embody Parisian chic with this exquisite sleeveless mini dress. Meticulously crafted from a luxurious white and black tweed fabric, this piece showcases the brand's iconic aesthetic. It features a flattering sheath silhouette, a round neckline, and contrasting black trim along the neck, armholes, waist, pockets, and hem. Ornate silver-tone buttons adorn the faux chest pockets, hip pockets, and shoulders, adding a touch of opulence. This dress is a perfect choice for sophisticated day-to-evening wear."
    }
  },
  {
    "core_identifiers": {
      "sku": "999039",
      "upc": "197855034921",
      "brand": "Maison Onyx",
      "product_name": "Abstract Print Cowl Neck Slip Dress"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Multi-Color",
      "color_hex": "#0047AB",
      "material": "Satin",
      "fit_type": "Slim",
      "care_instructions": "Hand wash cold. Do not bleach. Hang to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Dress",
      "collection": "Summer Pop Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 75.0,
      "current_price": 59.99,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/999039.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/dress/999039_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A multi-colored slip dress with a cowl neck and spaghetti straps, featuring a vibrant abstract geometric pattern."
    },
    "description": {
      "short": "A stunning slip dress with a cowl neckline and a vibrant, multi-colored abstract print. Made from a silky satin material.",
      "long": "Make a bold statement with our Abstract Print Cowl Neck Slip Dress. This eye-catching piece features a flattering cowl neckline and delicate spaghetti straps. The smooth satin fabric drapes beautifully over the body in a slim-fit silhouette. The energetic, multi-colored abstract pattern in shades of blue, green, pink, and orange ensures you'll stand out in any crowd. Perfect for a night out or a special occasion."
    }
  },
  {
    "core_identifiers": {
      "sku": "129037",
      "upc": "840345129037",
      "brand": "Maison Onyx",
      "product_name": "Women's Quilted Leather Chelsea Boot"
    },
    "attributes": {
      "size": null,
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Leather",
      "fit_type": "Standard",
      "care_instructions": "Wipe clean with a damp cloth. Use leather conditioner periodically."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Boots",
      "collection": "Autumn Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 225.0,
      "current_price": 180.0,
      "cost_price": 85.0,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/129037.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/129037_min.png",
      "gallery_urls": [],
      "alt_text": "A black leather women's Chelsea boot with a quilted pattern on the heel, elastic side panel, and a small gold logo accent, shown from the side on a white background."
    },
    "description": {
      "short": "A chic and timeless black leather Chelsea boot featuring elegant quilted detailing on the heel and a comfortable fit for everyday wear.",
      "long": "Elevate your footwear collection with our Quilted Leather Chelsea Boot. This classic silhouette is updated with a sophisticated quilted pattern on the heel counter for a touch of texture and modern flair. Crafted from supple black leather, it features traditional elastic side gores and a heel pull-tab for easy on and off. The low block heel provides subtle lift and all-day comfort, making it the perfect versatile boot to pair with everything from jeans to dresses."
    }
  },
  {
    "core_identifiers": {
      "sku": "190222",
      "upc": "850055109876",
      "brand": "Maison Onyx",
      "product_name": "Women's Classic Leather Riding Boot"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Cognac",
      "color_hex": "#6F4E37",
      "material": "Full-Grain Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a damp cloth. Apply leather conditioner periodically to maintain suppleness and shine."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Equestrian Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 349.99,
      "current_price": 279.99,
      "cost_price": 145.5,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/190222.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/190222_min.png",
      "gallery_urls": [],
      "alt_text": "A pair of women's brown leather knee-high riding boots, shown from the front on a white background."
    },
    "description": {
      "short": "Timeless elegance meets modern comfort in these classic leather riding boots, perfect for any occasion.",
      "long": "Crafted from premium full-grain leather, our Classic Leather Riding Boots offer a sophisticated silhouette and enduring style. These knee-high boots feature a sleek design with a full-length side zipper for a secure and comfortable fit. The rich cognac color adds a touch of warmth and versatility to your wardrobe. With a durable sole and a slight heel, they provide both comfort for all-day wear and a flattering lift. Perfect for pairing with skinny jeans, leggings, or skirts for a polished, equestrian-inspired look."
    }
  },
  {
    "core_identifiers": {
      "sku": "191921",
      "upc": "840289901234",
      "brand": "Maison Onyx",
      "product_name": "Pearl Embellished Satin Slingback Pumps"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Satin",
      "fit_type": "Standard",
      "care_instructions": "Spot clean with a soft, damp cloth. Avoid direct contact with liquids and harsh chemicals."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Heels",
      "collection": "Evening Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 495.0,
      "current_price": 450.0,
      "cost_price": 280.5,
      "in_stock": true,
      "stock_quantity": 88,
      "sales_velocity": "average",
      "sales_reasoning": "Classic style with a trendy embellishment, appealing to the formal and evening wear market.",
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/191921.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/191921_min.png",
      "gallery_urls": [],
      "alt_text": "A black satin pointed-toe slingback pump with a stiletto heel and a decorative strap across the instep embellished with white pearls of various sizes."
    },
    "description": {
      "short": "An elegant black satin slingback pump featuring a pointed toe and a stunning pearl-embellished strap, perfect for formal occasions.",
      "long": "Step into sophistication with our Pearl Embellished Satin Slingback Pumps. Crafted from luxurious black satin, these shoes boast a timeless pointed-toe design and a sleek stiletto heel. The defining feature is the exquisite strap across the instep, adorned with a cascade of lustrous white pearls that adds a touch of glamour and refinement. The adjustable slingback ensures a secure and comfortable fit, making these heels an ideal choice for weddings, galas, or any event where you want to make a memorable impression. The interior is lined with supple leather for ultimate comfort."
    }
  },
  {
    "core_identifiers": {
      "sku": "192223",
      "upc": "840364119223",
      "brand": "Modern Muse",
      "product_name": "Tweed Frayed Edge Slingback Pump"
    },
    "attributes": {
      "size": null,
      "color_name": "Beige Multi",
      "color_hex": "#D8CFC4",
      "material": "Tweed",
      "fit_type": "Standard",
      "care_instructions": "Spot clean only with a soft, damp cloth. Do not machine wash."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Heels",
      "collection": "Autumn Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 155.0,
      "current_price": 139.99,
      "cost_price": 68.5,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/192223.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/192223_min.png",
      "gallery_urls": [],
      "alt_text": "A side view of a women's slingback pump made of multicolor tweed fabric, featuring a low block heel, a square toe, and frayed edges along the topline and strap."
    },
    "description": {
      "short": "A sophisticated slingback pump crafted from classic multicolor tweed with contemporary frayed edge detailing and a comfortable low block heel.",
      "long": "Elevate your wardrobe with our Tweed Frayed Edge Slingback Pump. This shoe combines timeless elegance with modern texture, featuring a rich, multicolor tweed fabric. The design is highlighted by delicate frayed edges along the opening and slingback strap, adding a touch of effortless chic. A modest block heel provides stable, all-day comfort, making it a versatile choice for both professional settings and special occasions. The adjustable slingback ensures a perfect fit, blending style and practicality seamlessly."
    }
  },
  {
    "core_identifiers": {
      "sku": "192831",
      "upc": "849302175643",
      "brand": "Modern Muse",
      "product_name": "Two-Tone Cap-Toe Ballet Flats"
    },
    "attributes": {
      "size": "7.5",
      "color_name": "Beige/Black",
      "color_hex": "#DDCDBA",
      "material": "Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a soft, damp cloth. Use leather conditioner to maintain suppleness."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Flats",
      "collection": "Everyday Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 110.0,
      "current_price": 89.99,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/192831.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/192831_min.png",
      "gallery_urls": [],
      "alt_text": "A pair of women's beige leather ballet flats with a contrasting black cap toe, shown on a white background."
    },
    "description": {
      "short": "Classic and chic, these leather ballet flats feature a timeless two-tone design with a comfortable fit for all-day wear.",
      "long": "Step into timeless style with our Two-Tone Cap-Toe Ballet Flats. Expertly crafted from soft, genuine leather, these elegant flats feature a sophisticated beige body complemented by a classic black cap toe. The slip-on design ensures easy wear, while the cushioned insole and minimal heel provide superior comfort from morning to night. Perfect for pairing with workwear or casual outfits, these versatile flats are a must-have addition to any wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "222333",
      "upc": "196942123456",
      "brand": "Aurum",
      "product_name": "Suede Platform Block Heel Sandal"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Taupe",
      "color_hex": "#C0B2A4",
      "material": "Suede",
      "fit_type": "Regular",
      "care_instructions": "Spot clean only. Protect suede from moisture."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Sandals",
      "collection": "Summer 2024"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 125.0,
      "current_price": 99.99,
      "cost_price": 48.5,
      "in_stock": true,
      "stock_quantity": 287,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/222333.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/222333_min.png",
      "gallery_urls": [],
      "alt_text": "A women's taupe suede platform sandal with a stacked wooden block heel and an ankle strap with a gold buckle, shown from the side against a white background."
    },
    "description": {
      "short": "Elevate your look with these chic platform sandals, crafted from soft taupe suede. Featuring a bold stacked block heel and a secure ankle strap, they offer both style and comfort.",
      "long": "Make a statement with our Suede Platform Block Heel Sandal. Designed with a comfortable open-toe silhouette and a soft suede upper, these sandals are perfect for any warm-weather occasion. The sturdy platform and high block heel have a stylish wood-grain finish, providing significant lift without sacrificing stability. An adjustable ankle strap with a classic gold-tone buckle ensures a secure and customized fit. These versatile sandals pair beautifully with dresses, skirts, or your favorite pair of jeans."
    }
  },
  {
    "core_identifiers": {
      "sku": "345745",
      "upc": "850067123456",
      "brand": "Neon & Co.",
      "product_name": "Lasocki Strappy Kitten Heel Sandal"
    },
    "attributes": {
      "size": "7.5",
      "color_name": "Lilac",
      "color_hex": "#C8A2C8",
      "material": "Faux Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a damp cloth."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Heels",
      "collection": "Spring Summer 2024"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 75.0,
      "current_price": 59.99,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 245,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/345745.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/345745_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Side view of a lilac strappy kitten heel sandal with a square toe and adjustable ankle straps."
    },
    "description": {
      "short": "Elegant lilac kitten heel sandals featuring delicate criss-cross straps, a modern square toe, and adjustable ankle support for a chic and comfortable fit.",
      "long": "Step into sophistication with our Lasocki Strappy Kitten Heel Sandal. Crafted in a lovely lilac faux leather, these sandals offer both style and comfort. The design features multiple delicate straps that artfully cross the foot, leading to two adjustable ankle straps with silver-tone buckles for a secure fit. A modest kitten heel provides a subtle lift, perfect for all-day wear, while the contemporary open square toe adds a modern touch. These versatile heels are perfect for dressing up any outfit, from casual daytime looks to elegant evening ensembles."
    }
  },
  {
    "core_identifiers": {
      "sku": "39288",
      "upc": "196852123456",
      "brand": "Modern Muse",
      "product_name": "Quilted Leather Espadrille Slip-On"
    },
    "attributes": {
      "size": "8",
      "color_name": "Cream",
      "color_hex": "#FFFDD0",
      "material": "Leather, Jute",
      "fit_type": "Regular",
      "care_instructions": "Spot clean with a damp cloth. Do not submerge in water."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Summer Seaside Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 145.0,
      "current_price": 119.99,
      "cost_price": 55.75,
      "in_stock": true,
      "stock_quantity": 248,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/39288.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/39288_min.png",
      "gallery_urls": [],
      "alt_text": "Side view of a women's cream quilted leather espadrille with a jute sole."
    },
    "description": {
      "short": "Effortless style meets comfort in our quilted leather espadrilles, perfect for any sunny day.",
      "long": "Step into summer with our beautifully crafted Quilted Leather Espadrille Slip-Ons. Featuring a soft, diamond-quilted leather upper in a versatile cream color and a classic jute-wrapped midsole. The durable rubber outsole provides traction and longevity, while the slip-on design ensures easy wear. A subtle pull-tab at the heel adds a functional touch. These espadrilles are the perfect blend of casual elegance, ideal for pairing with everything from sundresses to your favorite jeans."
    }
  },
  {
    "core_identifiers": {
      "sku": "473843",
      "upc": "810155047384",
      "brand": "Maison Onyx",
      "product_name": "Classic Pointed Toe Stiletto Pumps"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Patent Leather",
      "fit_type": "Standard",
      "care_instructions": "Wipe clean with a soft, damp cloth. Avoid contact with sharp objects to prevent scratches."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Heels",
      "collection": "Signature Styles"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 120.0,
      "current_price": 95.0,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 345,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/473843.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/473843_min.png",
      "gallery_urls": [],
      "alt_text": "A single classic black patent leather stiletto pump with a pointed toe, viewed from the side against a white background."
    },
    "description": {
      "short": "A timeless and elegant black stiletto pump, crafted from glossy patent leather with a classic pointed toe. The perfect heel for any formal or professional occasion.",
      "long": "Step into sophistication with our Classic Pointed Toe Stiletto Pumps. These beautifully crafted heels feature a high-shine patent leather finish that exudes luxury. The sleek, pointed toe design elongates the leg for a flattering silhouette, while the slender stiletto heel provides a confident lift. Designed for both style and comfort, these versatile pumps are a wardrobe essential, seamlessly transitioning from boardroom meetings to evening cocktails. Pair them with a tailored suit for a powerful professional look or with your favorite dress for a night out."
    }
  },
  {
    "core_identifiers": {
      "sku": "555877",
      "upc": "195847362951",
      "brand": "Maison Onyx",
      "product_name": "Sutton Classic Riding Boot"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Cognac",
      "color_hex": "#834333",
      "material": "Full-Grain Leather",
      "fit_type": "Knee-High",
      "care_instructions": "Wipe clean with a damp cloth. Use leather conditioner periodically. Do not submerge in water."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Equestrian Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 349.99,
      "current_price": 299.99,
      "cost_price": 145.5,
      "in_stock": true,
      "stock_quantity": 182,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/555877.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/555877_min.png",
      "gallery_urls": [],
      "alt_text": "Profile view of a women's knee-high riding boot in cognac brown leather with a low heel, against a white background."
    },
    "description": {
      "short": "A timeless knee-high riding boot crafted from rich, full-grain leather for a sophisticated and classic look.",
      "long": "Step out in style with the Sutton Classic Riding Boot. This elegant knee-high boot is meticulously crafted from premium full-grain leather in a warm cognac hue. Featuring a sleek silhouette, a comfortable low block heel, and a convenient pull-tab at the top, this boot combines timeless equestrian style with modern comfort. The durable construction and classic design make it a versatile staple for any wardrobe, perfect for pairing with jeans, leggings, or dresses."
    }
  },
  {
    "core_identifiers": {
      "sku": "584922",
      "upc": "850024584922",
      "brand": "Maison Onyx",
      "product_name": "Suede Ankle Strap Block Heel Pump"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Suede",
      "fit_type": "Standard",
      "care_instructions": "Spot clean with a suede brush. Use a protective spray to prevent water damage."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Modern Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 135.0,
      "current_price": 110.0,
      "cost_price": 52.75,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/584922.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/584922_min.png",
      "gallery_urls": [],
      "alt_text": "A side profile of a women's black suede pump with a block heel and a thin ankle strap with a silver buckle, on a white background."
    },
    "description": {
      "short": "An elegant and versatile black suede pump featuring a comfortable block heel and a secure ankle strap.",
      "long": "Elevate your wardrobe with our Suede Ankle Strap Block Heel Pump. Crafted from luxurious black suede, this shoe is designed for both style and comfort. The sturdy block heel offers stability for all-day wear, while the adjustable ankle strap provides a secure and flattering fit. Its timeless design makes it a perfect choice for the office, special occasions, or a chic everyday look. The interior is lined with smooth leather for added comfort."
    }
  },
  {
    "core_identifiers": {
      "sku": "632567",
      "upc": "840348162951",
      "brand": "Modern Muse",
      "product_name": "Gola Retro Color-Block Runner"
    },
    "attributes": {
      "size": "US 9",
      "color_name": "Red/Teal",
      "color_hex": "#D81E34",
      "material": "Suede, Nylon",
      "fit_type": "Regular",
      "care_instructions": "Spot clean with a damp cloth. Do not machine wash."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Heritage Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 95.0,
      "current_price": 89.99,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 315,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/632567.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/632567_min.png",
      "gallery_urls": [],
      "alt_text": "A side view of a retro-style running shoe with a red and teal upper, white stripes, white laces, and a gum sole."
    },
    "description": {
      "short": "A vibrant, retro-inspired sneaker featuring a bold color-block design in red and teal with classic white accents.",
      "long": "Inspired by classic running silhouettes, this Gola sneaker brings a touch of vintage athletic style to your wardrobe. The upper features a dynamic combination of red nylon and suede panels, contrasted with a vibrant teal suede toe cap. The iconic white wingflash branding on the side, a cushioned EVA midsole, and a durable gum rubber outsole for superior grip complete this timeless and comfortable design."
    }
  },
  {
    "core_identifiers": {
      "sku": "634522",
      "upc": "850061234567",
      "brand": "Aurum",
      "product_name": "Classic Leather Ballet Flats"
    },
    "attributes": {
      "size": "7.5",
      "color_name": "Lavender",
      "color_hex": "#C8BFE7",
      "material": "Leather",
      "fit_type": "Classic",
      "care_instructions": "Wipe clean with a soft, damp cloth. Avoid contact with water."
    },
    "categorization": {
      "department": "Women",
      "category": "Shoes",
      "sub_category": "Footwear",
      "collection": "Spring Bloom Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 110.0,
      "current_price": 89.99,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/634522.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/634522_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A pair of women's lavender leather ballet flats with a round toe and a delicate bow detail, on a white background."
    },
    "description": {
      "short": "Timeless and versatile, these lavender ballet flats are crafted from supple leather for a comfortable, classic look.",
      "long": "Discover effortless elegance with our Classic Leather Ballet Flats. Made from premium, soft leather in a delicate lavender shade, these shoes are the epitome of comfort and style. Featuring a traditional round toe, a dainty bow accent, and a cushioned footbed for all-day wear. The flexible sole provides durability and ease of movement. These flats are a perfect addition to any wardrobe, easily pairing with casual jeans or a formal dress."
    }
  },
  {
    "core_identifiers": {
      "sku": "663452",
      "upc": "789012345678",
      "brand": "Neon & Co.",
      "product_name": "White Chunky Platform Sneaker"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "White",
      "color_hex": "#FFFFFF",
      "material": "Faux Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a damp cloth. Do not bleach or tumble dry."
    },
    "categorization": {
      "department": "Women's",
      "category": "Footwear",
      "sub_category": "Sneakers",
      "collection": "Urban Edge"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 95.0,
      "current_price": 79.99,
      "cost_price": 38.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/663452.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/663452_min.jpeg",
      "gallery_urls": [],
      "alt_text": "Side view of a women's all-white chunky platform sneaker with a thick, sculpted sole and classic lace-up front."
    },
    "description": {
      "short": "Elevate your look with these bold, all-white chunky platform sneakers, perfect for adding a trendy, retro-inspired touch to any outfit.",
      "long": "Step into the spotlight with our White Chunky Platform Sneakers. These shoes feature a thick, sculpted platform sole that provides both height and a dramatic silhouette. The upper is crafted from smooth, durable faux leather with stitched panel details for a classic athletic look. A padded collar and tongue, along with a secure lace-up closure, ensure a comfortable and supportive fit. These versatile sneakers are the perfect statement piece to pair with jeans, skirts, or dresses for a modern, fashion-forward style."
    }
  },
  {
    "core_identifiers": {
      "sku": "724354",
      "upc": "840342198765",
      "brand": "Maison Onyx",
      "product_name": "Black Platform Chelsea Boots"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Faux Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a damp cloth. Do not machine wash."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Urban Explorer"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 125.0,
      "current_price": 99.99,
      "cost_price": 48.5,
      "in_stock": true,
      "stock_quantity": 315,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/724354.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/724354_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A pair of women's black platform Chelsea boots with a chunky lug sole and block heel, viewed from the side on a white background."
    },
    "description": {
      "short": "Step up your style with these bold and edgy platform Chelsea boots. Featuring a chunky heel and lug sole for a commanding presence.",
      "long": "Introducing our Black Platform Chelsea Boots, the ultimate statement piece for any modern wardrobe. These boots are crafted from high-quality faux leather and feature the classic Chelsea boot silhouette with elastic side gores and pull tabs for easy on-and-off wear. The dramatic chunky platform and block heel provide significant lift and an on-trend look, while the rugged lug sole ensures excellent traction and durability. Perfect for pairing with jeans, skirts, or dresses, these boots add an instant touch of cool to any outfit."
    }
  },
  {
    "core_identifiers": {
      "sku": "725345",
      "upc": "198765432109",
      "brand": "Aurum",
      "product_name": "AuraStep Ventilated Comfort Clogs"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Sand",
      "color_hex": "#D2B48C",
      "material": "EVA Foam",
      "fit_type": "Relaxed",
      "care_instructions": "Wipe clean with a damp cloth. Air dry."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Summer Comfort"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 59.99,
      "current_price": 44.99,
      "cost_price": 22.5,
      "in_stock": true,
      "stock_quantity": 245,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/725345.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/725345_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A pair of sand-colored ventilated foam clogs shown at a three-quarter angle on a white background."
    },
    "description": {
      "short": "Lightweight, breathable, and incredibly comfortable. The perfect slip-on for any casual occasion, crafted from durable EVA foam.",
      "long": "Discover ultimate comfort and breathability with our Ventilated Comfort Clogs. Crafted from a single piece of durable and lightweight EVA foam, these clogs are designed for all-day wear. The strategically placed ventilation ports across the top and sides keep your feet cool and help shed water and debris, making them ideal for the beach, garden, or just lounging around. The slip-on, backless design and roomy fit ensure easy on-and-off, while the contoured footbed provides gentle support. Easy to clean and quick to dry, these clogs will quickly become your go-to footwear choice."
    }
  },
  {
    "core_identifiers": {
      "sku": "734222",
      "upc": "850059382147",
      "brand": "Maison Onyx",
      "product_name": "Chunky Platform Fisherman Sandal"
    },
    "attributes": {
      "size": "8",
      "color_name": "Black",
      "color_hex": "#000000",
      "material": "Faux Leather",
      "fit_type": "Regular",
      "care_instructions": "Wipe clean with a damp cloth."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Summer City Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 85.0,
      "current_price": 74.99,
      "cost_price": 38.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734222.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734222_min.png",
      "gallery_urls": [],
      "alt_text": "A black platform fisherman sandal with a chunky lug sole and a woven caged upper, shown from the side against a white background."
    },
    "description": {
      "short": "A modern take on a classic, these black fisherman sandals feature a bold platform lug sole and a comfortable woven design.",
      "long": "Step into contemporary style with our Chunky Platform Fisherman Sandals. These sandals feature a classic caged upper crafted from smooth black faux leather, complete with an adjustable ankle strap for a secure and comfortable fit. The standout feature is the thick, treaded platform sole that adds significant height and a modern, edgy look while ensuring all-day comfort and stability. Perfect for pairing with summer dresses, shorts, or your favorite jeans, these sandals are a versatile must-have for any fashion-forward wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "734522",
      "upc": "850024567890",
      "brand": "Maison Onyx",
      "product_name": "Metallic Silver Pointed-Toe Knee-High Boot"
    },
    "attributes": {
      "size": "8.5",
      "color_name": "Silver",
      "color_hex": "#C0C0C0",
      "material": "Metallic Faux Leather",
      "fit_type": "Slim Fit",
      "care_instructions": "Wipe clean with a soft, damp cloth. Do not machine wash. Store in a cool, dry place away from direct sunlight."
    },
    "categorization": {
      "department": "Women",
      "category": "Footwear",
      "sub_category": "Boots",
      "collection": "Cosmic Glam"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 275.0,
      "current_price": 220.0,
      "cost_price": 110.5,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734522.jpeg",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734522_min.jpeg",
      "gallery_urls": [],
      "alt_text": "A side profile of a women's knee-high boot with a metallic silver finish, a high stiletto heel, and a pointed toe, set against a white background."
    },
    "description": {
      "short": "Make a bold statement with these striking knee-high boots, crafted in a high-shine metallic silver finish for a futuristic and glamorous look.",
      "long": "Step into the spotlight with our Metallic Silver Pointed-Toe Knee-High Boots. Designed for the fashion-forward individual, these boots feature a sleek, liquid-metal appearance that is sure to turn heads. The sharp pointed toe and slender stiletto heel create an elegant and powerful silhouette. Crafted from a high-quality metallic faux leather, they offer a comfortable, form-fitting design that hugs the calf. Perfect for evening events, parties, or adding a dose of high-fashion drama to any outfit."
    }
  },
  {
    "core_identifiers": {
      "sku": "734555",
      "upc": "198765432109",
      "brand": "Modern Muse",
      "product_name": "LA Originals Classic High-Top Sneakers"
    },
    "attributes": {
      "size": null,
      "color_name": "White/Black",
      "color_hex": "#FFFFFF",
      "material": "Canvas",
      "fit_type": "Standard",
      "care_instructions": "Spot clean with a damp cloth. Do not machine wash."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Footwear",
      "collection": "Urban Classics Collection"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 85.0,
      "current_price": 74.99,
      "cost_price": 35.5,
      "in_stock": true,
      "stock_quantity": 342,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734555.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/shoes/734555_min.png",
      "gallery_urls": [],
      "alt_text": "A pair of white high-top sneakers with black accents and a geometric logo on the side, set against a white background."
    },
    "description": {
      "short": "Classic high-top sneakers in a timeless white and black colorway, perfect for everyday urban style.",
      "long": "Step up your sneaker game with the LA Originals Classic High-Top. Featuring a durable canvas upper, a comfortable padded collar, and a vulcanized rubber outsole for excellent grip and flexibility. The iconic black geometric logo on the side adds a bold statement to the clean white design. Finished with classic lace-up closure and a branded tongue patch, these sneakers blend retro vibes with modern comfort for a versatile look that pairs with anything."
    }
  },
  {
    "core_identifiers": {
      "sku": "109244",
      "upc": "198765432109",
      "brand": "Modern Muse",
      "product_name": "Breton Stripe Long Sleeve Top with Button Cuffs"
    },
    "attributes": {
      "size": "M",
      "color_name": "Navy/Cream",
      "color_hex": "#0F1A2D",
      "material": "Cotton Blend",
      "fit_type": "Regular",
      "care_instructions": "Machine wash cold, lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Modern Nautical"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 185.0,
      "current_price": 185.0,
      "cost_price": 78.0,
      "in_stock": true,
      "stock_quantity": 352,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/109244.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/109244_min.png",
      "gallery_urls": [],
      "alt_text": "Women's navy and cream striped long-sleeve top with gold button details on the cuffs, viewed from the front."
    },
    "description": {
      "short": "A timeless long-sleeve top featuring classic navy and cream Breton stripes. Elevated with distinctive wide cuffs adorned with decorative gold-tone buttons.",
      "long": "Embrace classic Parisian chic with this elegant Breton stripe top. Crafted from a soft and comfortable knit fabric, this piece features a timeless crew neckline and long sleeves. The design is elevated by sophisticated wide cuffs, each detailed with a row of polished gold-tone buttons. Its versatile navy and cream pattern makes it a perfect staple for any wardrobe, easily paired with jeans for a casual look or trousers for a more polished ensemble."
    }
  },
  {
    "core_identifiers": {
      "sku": "199902",
      "upc": "850062451893",
      "brand": "Maison Onyx",
      "product_name": "Silk and Lace Camisole"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Champagne",
      "color_hex": "#F7E7CE",
      "material": "Silk, Lace",
      "fit_type": "Regular",
      "care_instructions": "Hand wash cold with mild detergent. Do not bleach. Lay flat to dry. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Seraphina"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 68.0,
      "current_price": 54.99,
      "cost_price": 25.5,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/199902.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/199902_min.png",
      "gallery_urls": [],
      "alt_text": "A champagne-colored silk camisole with delicate lace trim along the v-neckline and hem, featuring thin adjustable straps."
    },
    "description": {
      "short": "A luxurious silk camisole adorned with intricate lace trim, perfect for sleep or elegant layering.",
      "long": "Experience everyday luxury with our Silk and Lace Camisole. Crafted from smooth, lustrous silk, this piece feels incredibly soft against the skin. It is beautifully designed with delicate, scalloped lace detailing on the v-neckline and hem, adding a touch of romantic femininity. The adjustable spaghetti straps provide a customizable and comfortable fit. This versatile camisole can be worn as elegant sleepwear or layered under a blazer for a sophisticated day-to-night ensemble."
    }
  },
  {
    "core_identifiers": {
      "sku": "234893",
      "upc": "195583749201",
      "brand": "Maison Onyx",
      "product_name": "Pearl Embellished Tweed Jacket"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Ecru/Black",
      "color_hex": "#F5F5DC",
      "material": "Tweed",
      "fit_type": "Classic Fit",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Outerwear",
      "collection": "M\u00e9tiers d'Art 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 495.0,
      "current_price": 450.0,
      "cost_price": 180.0,
      "in_stock": true,
      "stock_quantity": 8,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/234893.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/234893_min.png",
      "gallery_urls": [],
      "alt_text": "Black and white tweed jacket with pearl and gold button embellishments."
    },
    "description": {
      "short": "An iconic tweed jacket in black and white, featuring exquisite pearl trim along the collar, placket, and hem, finished with signature gold-tone buttons.",
      "long": "Embodying timeless elegance, thisjacket is crafted from a luxurious black and white tweed fabric. The classic, collarless silhouette is enhanced with intricate pearl detailing along the round neckline, central placket, cuffs, and hem. Four patch pockets and the front closure are adorned with ornate, textured gold-tone buttons. This piece is a testament to the house's legendary craftsmanship and an essential addition to any sophisticated wardrobe."
    }
  },
  {
    "core_identifiers": {
      "sku": "239944",
      "upc": "850024681357",
      "brand": "Modern Muse",
      "product_name": "Checkered Knit Sweater Vest"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black/Cream",
      "color_hex": "#F5F5DC",
      "material": "Wool Blend",
      "fit_type": "Regular Fit",
      "care_instructions": "Hand wash cold, lay flat to dry."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Fall/Winter 2023"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 85.0,
      "current_price": 70.0,
      "cost_price": 35.0,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/239944.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/239944_min.png",
      "gallery_urls": [],
      "alt_text": "A black and cream checkered v-neck knit sweater vest laid flat on a white surface."
    },
    "description": {
      "short": "A classic v-neck sweater vest featuring a bold black and cream checkerboard pattern, perfect for layering.",
      "long": "Stay warm and stylish with this timeless checkered knit sweater vest. Crafted from a soft, comfortable knit fabric, it features a classic v-neckline and ribbed trim along the neck, armholes, and hem. The striking black and cream checkerboard pattern makes a statement, offering a versatile piece that can be dressed up or down. Layer it over a crisp white shirt for a preppy look or a simple t-shirt for a more casual vibe."
    }
  },
  {
    "core_identifiers": {
      "sku": "292929",
      "upc": "195551292929",
      "brand": "Modern Muse",
      "product_name": "Pink Tweed Jacket"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Light Pink",
      "color_hex": "#F7C4C8",
      "material": "Tweed",
      "fit_type": "Classic Fit",
      "care_instructions": "Dry clean only"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Outerwear",
      "collection": "Ready-to-Wear"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 495.0,
      "current_price": 450.0,
      "cost_price": 180.0,
      "in_stock": true,
      "stock_quantity": 300,
      "sales_velocity": "low",
      "sales_reasoning": null,
      "q4_2025": "50 (-16%)",
      "q1_2026": "10 (-20%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/292929.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/292929_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a  light pink tweed jacket with a collarless design, braided trim, and four patch pockets with gold logo buttons."
    },
    "description": {
      "short": "An iconic tweed jacket in a soft light pink hue. This timeless piece features a classic collarless silhouette, intricate braided trim, and signature gold-tone CC logo buttons.",
      "long": "Crafted with the legendary savoir-faire of the House of , this jacket is a masterpiece of textile and tailoring. Made from a luxurious light pink tweed, it offers a structured yet comfortable fit. The design is distinguished by its clean, collarless neckline, button-front closure, and four practical patch pockets. Delicate braided trim elegantly outlines the collar, placket, cuffs, and pockets, adding texture and refinement. Each gold-tone button is adorned with the iconic interlocking CC logo, making this jacket an unmistakable symbol of Parisian elegance."
    }
  },
  {
    "core_identifiers": {
      "sku": "335234",
      "upc": "850055123456",
      "brand": "Neon & Co.",
      "product_name": "Kaleidoscope Geometric Print Shirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Multicolor",
      "color_hex": "#D42D3A",
      "material": "100% Cotton",
      "fit_type": "Regular Fit",
      "care_instructions": "Machine wash cold with like colors. Tumble dry low. Do not bleach."
    },
    "categorization": {
      "department": "Men",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Vibrant Geometry"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 85.0,
      "current_price": 72.5,
      "cost_price": 35.0,
      "in_stock": true,
      "stock_quantity": 188,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/335234.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/335234_min.png",
      "gallery_urls": [],
      "alt_text": "Men's long-sleeve button-down shirt with a colorful geometric diamond pattern in red, blue, and yellow."
    },
    "description": {
      "short": "A vibrant and eye-catching long-sleeve shirt featuring a bold geometric diamond pattern in primary colors.",
      "long": "Make a bold statement with our Kaleidoscope Geometric Print Shirt. Crafted from comfortable and breathable 100% cotton, this shirt is perfect for all-day wear. It features a striking all-over geometric pattern of diamonds and lines in a vivid palette of red, blue, and yellow. Designed with a classic point collar, full button-front closure, and long sleeves with buttoned cuffs, this regular fit shirt offers a timeless silhouette with a modern, artistic twist. Ideal for casual outings, parties, or any occasion where you want to stand out."
    }
  },
  {
    "core_identifiers": {
      "sku": "349022",
      "upc": "850051123456",
      "brand": "Modern Muse",
      "product_name": "Emerald Green Satin High-Neck Blouse"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Emerald Green",
      "color_hex": "#00573D",
      "material": "Satin",
      "fit_type": "Regular Fit",
      "care_instructions": "Dry clean recommended"
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Evening Elegance"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 120.0,
      "current_price": 95.0,
      "cost_price": 45.5,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/349022.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/349022_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of an emerald green satin long-sleeve blouse with a high mock neck and button details."
    },
    "description": {
      "short": "An elegant high-neck blouse crafted from luxurious emerald green satin, perfect for sophisticated day-to-night looks.",
      "long": "Exude timeless elegance with our High-Neck Satin Blouse. Cut from lustrous emerald green satin, this piece features a sophisticated mock turtleneck with delicate button accents and soft gathering for a flattering drape. The long blouson sleeves are finished with wide, structured cuffs, adding a touch of classic drama. This versatile top can be dressed up with a tailored skirt for the office or paired with sleek trousers for an evening out."
    }
  },
  {
    "core_identifiers": {
      "sku": "394855",
      "upc": "197483659201",
      "brand": "Modern Muse",
      "product_name": "Relaxed Fit Long Sleeve Button-Down Shirt"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "White",
      "color_hex": "#FFFFFF",
      "material": "Polyester Blend",
      "fit_type": "Relaxed",
      "care_instructions": "Machine wash cold. Do not bleach. Tumble dry low. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Modern Essentials"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 79.5,
      "current_price": 64.99,
      "cost_price": 32.75,
      "in_stock": true,
      "stock_quantity": 312,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/394855.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/394855_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a white relaxed fit long-sleeve button-down shirt with rolled-up cuffs."
    },
    "description": {
      "short": "A timeless white button-down shirt featuring a relaxed fit and roll-tab sleeves for versatile styling.",
      "long": "Experience effortless sophistication with our Relaxed Fit Long Sleeve Button-Down Shirt. Crafted from a smooth, lightweight fabric, this shirt offers all-day comfort and a polished look. It features a classic point collar, a clean button front, and long sleeves with convenient roll-tabs. The relaxed silhouette and curved high-low hem make it perfect for wearing tucked, half-tucked, or loose over your favorite pants or skirts. A true wardrobe essential for any occasion."
    }
  },
  {
    "core_identifiers": {
      "sku": "595544",
      "upc": "840293117541",
      "brand": "Modern Muse",
      "product_name": "Breton Stripe Button-Cuff Sweater"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Navy/Cream",
      "color_hex": "#1A2238",
      "material": "Cotton Blend",
      "fit_type": "Slim Fit",
      "care_instructions": "Machine wash cold on gentle cycle, lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Nautical Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 128.0,
      "current_price": 110.0,
      "cost_price": 55.0,
      "in_stock": true,
      "stock_quantity": 345,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/595544.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/595544_min.png",
      "gallery_urls": [],
      "alt_text": "A women's long-sleeve sweater with navy and cream horizontal stripes, a crew neck, and solid navy cuffs with three gold buttons."
    },
    "description": {
      "short": "A classic Breton stripe sweater featuring a slim fit and elegant gold-tone button details on the cuffs. A timeless piece for any wardrobe.",
      "long": "Embrace timeless nautical charm with our Breton Stripe Button-Cuff Sweater. Crafted from a comfortable cotton blend, this sweater offers a flattering slim fit that's perfect for layering. It features classic navy and cream stripes, a simple crew neckline, and is elevated by solid navy cuffs adorned with decorative gold-tone buttons. This versatile top can be dressed up with trousers or paired with your favorite jeans for a chic, casual look."
    }
  },
  {
    "core_identifiers": {
      "sku": "634523",
      "upc": "196013548721",
      "brand": "Maison Onyx",
      "product_name": "Satin Halter Neck Crop Top"
    },
    "attributes": {
      "size": "M",
      "color_name": "Royal Blue",
      "color_hex": "#4169E1",
      "material": "Satin",
      "fit_type": "Fitted",
      "care_instructions": "Hand wash cold. Do not bleach. Line dry. Cool iron if needed."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Evening Allure"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 78.0,
      "current_price": 65.0,
      "cost_price": 28.5,
      "in_stock": true,
      "stock_quantity": 215,
      "sales_velocity": "high",
      "sales_reasoning": "Popular item for parties and evening events.",
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/634523.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/634523_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a royal blue satin halter neck crop top with a high neckline and fitted silhouette, shown on a white background."
    },
    "description": {
      "short": "A stunning royal blue satin halter neck crop top, designed with a sleek high neckline and a fitted silhouette for a sophisticated look.",
      "long": "Crafted from luxurious, high-sheen satin, this royal blue top is a true statement piece. It features an elegant halter neckline that fastens with a discreet zipper at the back, a draped cowl detail at the front, and a cropped length that pairs perfectly with high-waisted skirts or trousers. The fitted design accentuates your shape, making it an ideal choice for a night out, a special occasion, or any event where you want to turn heads."
    }
  },
  {
    "core_identifiers": {
      "sku": "667734",
      "upc": "198765432109",
      "brand": "Modern Muse",
      "product_name": "Relaxed Fit Embroidered Hoodie"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Beige",
      "color_hex": "#C7B9A9",
      "material": "Cotton Blend",
      "fit_type": "Relaxed Fit",
      "care_instructions": "Machine wash cold with like colors. Tumble dry low. Do not bleach. Cool iron if needed."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Core Essentials"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 110.0,
      "current_price": 110.0,
      "cost_price": 42.5,
      "in_stock": true,
      "stock_quantity": 288,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/667734.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/667734_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a beige relaxed-fit hoodie with tonal embroidery on the chest, a drawstring hood, and a kangaroo pocket."
    },
    "description": {
      "short": "A comfortable, relaxed-fit hoodie in a versatile beige color, featuring a drawstring hood, kangaroo pocket, and subtle tonal embroidery on the chest.",
      "long": "Crafted for comfort and style, this beige hoodie is a wardrobe essential. Made from a soft cotton-blend fabric, it features a relaxed fit for easy layering and all-day comfort. The design includes a classic adjustable drawstring hood, a spacious front kangaroo pocket, and ribbed cuffs and hem to lock in warmth. A tonal embroidered logo on the chest adds a subtle, premium touch to this minimalist piece."
    }
  },
  {
    "core_identifiers": {
      "sku": "684321",
      "upc": "850044123456",
      "brand": "Aurum",
      "product_name": "Striped Bateau Neck Crop Top"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Black/White",
      "color_hex": "#000000",
      "material": "Cotton Blend",
      "fit_type": "Cropped",
      "care_instructions": "Machine wash cold, gentle cycle. Tumble dry low. Do not bleach."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Modern Classics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 58.0,
      "current_price": 49.99,
      "cost_price": 22.5,
      "in_stock": true,
      "stock_quantity": 287,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/684321.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/684321_min.png",
      "gallery_urls": [],
      "alt_text": "Women's black and white striped bateau neck crop top with three-quarter sleeves, shown on a white background."
    },
    "description": {
      "short": "A classic black and white striped crop top featuring an elegant bateau neckline and three-quarter sleeves. A timeless piece for any modern wardrobe.",
      "long": "Embrace timeless Parisian chic with our Striped Bateau Neck Crop Top. Crafted from a soft and comfortable cotton blend knit, this top offers a relaxed, slightly boxy fit that is both modern and comfortable. It features classic black and white horizontal stripes, an elegant bateau neckline that gracefully frames the collarbones, and versatile three-quarter length sleeves. The cropped hemline pairs perfectly with high-waisted jeans, skirts, or trousers for a polished yet effortless look. A versatile staple you'll reach for season after season."
    }
  },
  {
    "core_identifiers": {
      "sku": "733344",
      "upc": "198765432109",
      "brand": "Neon & Co.",
      "product_name": "Psychedelic Swirl Mesh Long-Sleeve Top"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Multicolor",
      "color_hex": "#D63A3A",
      "material": "Mesh",
      "fit_type": "Slim Fit",
      "care_instructions": "Hand wash cold, lay flat to dry."
    },
    "categorization": {
      "department": "Women",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Art Pop"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 125.0,
      "current_price": 99.99,
      "cost_price": 45.5,
      "in_stock": true,
      "stock_quantity": 237,
      "sales_velocity": "average",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/733344.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/733344_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of a women's long-sleeve mesh top with a colorful, abstract swirl and geometric pattern."
    },
    "description": {
      "short": "A vibrant, long-sleeve mesh top featuring a bold psychedelic print. Perfect for layering or as a statement piece.",
      "long": "Make a statement with this eye-catching long-sleeve top. Crafted from lightweight, breathable mesh, it offers a comfortable, body-hugging slim fit. The top is adorned with a dynamic and colorful abstract print, featuring swirls, checks, and geometric shapes in a palette of red, blue, yellow, and black. With a classic crew neck and full-length sleeves, this piece is perfect for layering under a jacket or over a bralette to create a bold, artistic look for any occasion."
    }
  },
  {
    "core_identifiers": {
      "sku": "734222",
      "upc": "850051234567",
      "brand": "Aurum",
      "product_name": "Balcont Vintage Wash Graphic Tee"
    },
    "attributes": {
      "size": "Medium",
      "color_name": "Washed Grey",
      "color_hex": "#70736E",
      "material": "100% Cotton",
      "fit_type": "Oversized",
      "care_instructions": "Machine wash cold inside out. Tumble dry low. Do not iron on print."
    },
    "categorization": {
      "department": "Unisex",
      "category": "Apparel",
      "sub_category": "Top",
      "collection": "Retro Graphics"
    },
    "commercial_status": {
      "currency": "USD",
      "msrp": 55.0,
      "current_price": 45.0,
      "cost_price": 22.5,
      "in_stock": true,
      "stock_quantity": 287,
      "sales_velocity": "high",
      "sales_reasoning": null,
      "q4_2025": "10 (-5%)",
      "q1_2026": "10 (-5%)"
    },
    "media": {
      "main_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/734222.png",
      "web_image_url": "https://storage.cloud.google.com/creative-content/catalog/top/734222_min.png",
      "gallery_urls": [],
      "alt_text": "Front view of an oversized, washed grey graphic t-shirt with a vintage 'BALCONT' print."
    },
    "description": {
      "short": "A vintage-inspired graphic tee with an oversized fit, crafted from soft, washed cotton for a lived-in feel.",
      "long": "Channel retro vibes with the Balcont Vintage Wash Graphic Tee. This t-shirt is made from premium, heavyweight cotton that has been specially washed for a super-soft, worn-in texture and a unique faded grey color. It features a relaxed, oversized silhouette with dropped shoulders for ultimate comfort. The front showcases a nostalgic 'BALCONT' graphic with a concert crowd illustration, printed with a cracked-ink effect to enhance the vintage aesthetic. Perfect for everyday wear, pair it with jeans or shorts for a cool, laid-back look."
    }
  }
]"""




def retrieve_products() -> List[Product]:
    # x = json.loads(product_data, object_hook=lambda d: Product(**d))
    x = json.loads(product_data)
    # print(x)

    # Convert to Product objects
    # products = [Product(json.loads(item, object_hook=lambda d: Product(**d))) for item in product_data]
    products = [Product(**item) for item in x]
    products = [p for p in products if p.commercial_status.sales_velocity == "low"]

    # print(products[0])
    return products 